package bg.tablesense;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@SpringBootApplication @EnableScheduling @RestController @RequestMapping("/api")
public class Application {
    public static class Table { public int id, x, y, s; public String st = "f"; @JsonIgnore public boolean present; }
    public static class Place { public String n; public double r, d, p; public List<Table> T = new ArrayList<>(); }

    static final Random RND = new Random(7);
    static final List<Place> PLACES = new ArrayList<>();
    static void add(String n, double r, double d, double p, int[][] t) {
        Place pl = new Place(); pl.n = n; pl.r = r; pl.d = d; pl.p = p; int i = 1;
        for (int[] a : t) { Table b = new Table(); b.id = i++; b.x = a[0]; b.y = a[1]; b.s = a[2]; b.present = RND.nextInt(100) < 45; pl.T.add(b); }
        PLACES.add(pl);
    }
    static {   // демонстрационни данни; реалните идват от сензори/служители
        add("Пълдин (Старият град)", 4.7, 0.4, 3, new int[][]{{90,70,2},{230,70,4},{370,70,4},{510,70,6},{90,190,2},{230,190,4},{370,190,6},{510,190,4},{110,310,8},{300,310,4},{490,310,2}});
        add("Хеброс (бул. Руски)", 4.6, 0.9, 4, new int[][]{{100,80,4},{260,80,4},{420,80,2},{100,230,6},{260,230,4},{420,230,2},{300,330,8}});
        add("Кафе в Капана", 4.4, 0.6, 2, new int[][]{{90,90,2},{220,90,2},{350,90,4},{480,90,2},{90,250,2},{220,250,4},{350,250,2},{480,250,6}});
    }

    // Вика C++ ядрото като отделен процес (команда през stdin, резултат през stdout)
    static String engine(String input) throws Exception {
        Process pr = new ProcessBuilder(System.getenv().getOrDefault("ENGINE", "./engine_cli")).redirectErrorStream(true).start();
        pr.getOutputStream().write((input + "\n").getBytes()); pr.getOutputStream().close();
        String out = new String(pr.getInputStream().readAllBytes()); pr.waitFor(); return out.trim();
    }

    static void scan(Place pl) throws Exception {
        StringBuilder sb = new StringBuilder("SCAN " + pl.T.size());
        for (Table t : pl.T) sb.append(' ').append(t.id).append(' ').append(Math.max(0, t.x / 20 - 2)).append(' ')
            .append(Math.max(0, t.y / 20 - 1)).append(" 4 3 ").append(t.s).append(' ').append(t.present ? 1 : 0);
        Map<Integer, Boolean> occ = new HashMap<>();
        for (String line : engine(sb.toString()).split("\n")) { String[] p = line.trim().split(" "); occ.put(Integer.parseInt(p[0]), p[1].equals("1")); }
        for (Table t : pl.T) if (!t.st.equals("r")) t.st = occ.get(t.id) ? "o" : "f";
    }

    @Scheduled(fixedRate = 4000)   // симулира потока от термо-камерите
    synchronized void tick() throws Exception {
        for (Place pl : PLACES) { Table t = pl.T.get(RND.nextInt(pl.T.size())); t.present = !t.present; scan(pl); }
    }

    @GetMapping("/places") synchronized List<Place> places() { return PLACES; }

    @GetMapping("/places/{i}/suggest")
    synchronized Map<String, Integer> suggest(@PathVariable int i, @RequestParam int party) throws Exception {
        Place pl = PLACES.get(i); StringBuilder sb = new StringBuilder("FIT " + party + " " + pl.T.size());
        for (Table t : pl.T) sb.append(' ').append(t.id).append(' ').append(t.s).append(' ').append(t.st.equals("f") ? 0 : 1);
        return Map.of("id", Integer.parseInt(engine(sb.toString())));
    }

    @PostMapping("/places/{i}/tables/{id}/reserve")
    synchronized ResponseEntity<Void> reserve(@PathVariable int i, @PathVariable int id) {
        for (Table t : PLACES.get(i).T) if (t.id == id && t.st.equals("f")) { t.st = "r"; return ResponseEntity.ok().build(); }
        return ResponseEntity.status(409).build();
    }

    @PostMapping("/places/{i}/tables/{id}/state")   // ръчно въвеждане от персонала (етап 1)
    synchronized void staff(@PathVariable int i, @PathVariable int id, @RequestParam String st) throws Exception {
        Place pl = PLACES.get(i);
        for (Table t : pl.T) if (t.id == id) { t.present = st.equals("o"); if (st.equals("f")) t.st = "f"; }
        scan(pl);
    }

    @GetMapping("/rank")
    synchronized String rank(@RequestParam double w0, @RequestParam double w1, @RequestParam double w2, @RequestParam double w3) throws Exception {
        StringBuilder sb = new StringBuilder("RANK " + w0 + " " + w1 + " " + w2 + " " + w3 + " " + PLACES.size());
        for (int k = 0; k < PLACES.size(); k++) { Place p = PLACES.get(k); double tot = 0, fr = 0;
            for (Table t : p.T) { tot += t.s; if (t.st.equals("f")) fr += t.s; }
            sb.append(' ').append(k).append(' ').append(fr / tot).append(' ').append(p.r).append(' ').append(p.d).append(' ').append(p.p); }
        return engine(sb.toString());
    }

    public static void main(String[] a) { SpringApplication.run(Application.class, a); }
}
