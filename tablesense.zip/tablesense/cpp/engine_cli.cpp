// CLI мост между Java и C++ ядрото. Команди през stdin:
// SCAN n (id x y w h seats present)*n   -> "id occ" за всяка маса (термо-симулация + EMA + хистерезис)
// FIT party n (id seats busy)*n         -> id на най-подходящата маса или -1
// RANK wF wR wD wP n (idx free rating km price)*n -> "idx score" по ред на класиране
#define main demo_main
#include "occupancy_engine.cpp"
#undef main
int main() {
    string cmd; cin >> cmd;
    if (cmd == "SCAN") {
        int n; cin >> n; Engine e; vector<int> pres(n);
        for (int i = 0; i < n; i++) { Table t; cin >> t.id >> t.x >> t.y >> t.w >> t.h >> t.seats >> pres[i]; e.tables.push_back(t); }
        mt19937 rng(42); normal_distribution<float> nz(0.f, 0.3f);
        for (int k = 0; k < 6; k++) {
            Frame f; for (auto& r : f) for (auto& c : r) c = 22.f + nz(rng);
            for (int i = 0; i < n; i++) if (pres[i]) { auto& t = e.tables[i];
                for (int y = t.y; y < min(H, t.y + t.h); y++) for (int x = t.x; x < min(W, t.x + t.w); x++) f[y][x] += 9; }
            e.update(f);
        }
        for (auto& t : e.tables) cout << t.id << " " << (t.occ ? 1 : 0) << "\n";
    } else if (cmd == "FIT") {
        int party, n; cin >> party >> n; Engine e;
        for (int i = 0; i < n; i++) { Table t; int busy; cin >> t.id >> t.seats >> busy; t.occ = busy; e.tables.push_back(t); }
        auto r = e.reserve(party); cout << (r ? *r : -1) << "\n";
    } else if (cmd == "RANK") {
        double w[4]; int n; cin >> w[0] >> w[1] >> w[2] >> w[3] >> n; vector<Place> p(n);
        for (auto& x : p) cin >> x.name >> x.freeRatio >> x.rating >> x.distanceKm >> x.price;
        rankPlaces(p, w[0], w[1], w[2], w[3]);
        for (auto& x : p) cout << x.name << " " << x.score << "\n";
    }
}
