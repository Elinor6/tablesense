// TableSense – ядро на backend (C++17)
// Компилация: g++ -std=c++17 -O2 occupancy_engine.cpp -o engine && ./engine
#include <bits/stdc++.h>
using namespace std;

constexpr int W = 32, H = 24;
using Frame = array<array<float, W>, H>;   // термо-кадър (°C), без лица и лични данни

struct Table { int id, x, y, w, h, seats; bool occ = false, reserved = false; float ema = 0; };

class Engine {
public:
    vector<Table> tables;
    float ambient = 22.f;

    // Алгоритъм 1: адаптивна температура на средата (медиана на кадъра, плавно обновяване)
    float median(const Frame& f) {
        vector<float> v; v.reserve(W * H);
        for (auto& r : f) for (float c : r) v.push_back(c);
        nth_element(v.begin(), v.begin() + v.size() / 2, v.end());
        return v[v.size() / 2];
    }

    // Алгоритъм 2: брой хора = брой топли „петна“ (BFS по свързани компоненти)
    int countPeople(const Frame& f, float thr) {
        vector<vector<bool>> seen(H, vector<bool>(W, false));
        int blobs = 0;
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            if (seen[y][x] || f[y][x] - ambient < thr) continue;
            blobs++; queue<pair<int,int>> q; q.push({y, x}); seen[y][x] = true;
            while (!q.empty()) {
                auto [cy, cx] = q.front(); q.pop();
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int ny = cy + dy, nx = cx + dx;
                    if (ny < 0 || nx < 0 || ny >= H || nx >= W || seen[ny][nx]) continue;
                    if (f[ny][nx] - ambient < thr) continue;
                    seen[ny][nx] = true; q.push({ny, nx});
                }
            }
        }
        return blobs;
    }

    // Алгоритъм 3: заетост на маса с EMA изглаждане + тригер на Шмит (хистерезис срещу мигане)
    void update(const Frame& f) {
        ambient = 0.95f * ambient + 0.05f * median(f);
        for (auto& t : tables) {
            float sum = 0; int n = 0;
            for (int y = t.y; y < min(H, t.y + t.h); y++)
                for (int x = t.x; x < min(W, t.x + t.w); x++) { sum += f[y][x] - ambient; n++; }
            float excess = n ? sum / n : 0;
            t.ema = 0.6f * t.ema + 0.4f * excess;
            if (!t.occ && t.ema > 1.5f) t.occ = true;
            else if (t.occ && t.ema < 0.7f) t.occ = false;
        }
    }

    // Алгоритъм 4: резервация „най-добро побиране“ – най-малката свободна маса, която става за групата
    optional<int> reserve(int party) {
        Table* best = nullptr;
        for (auto& t : tables)
            if (!t.occ && !t.reserved && t.seats >= party && (!best || t.seats < best->seats)) best = &t;
        if (!best) return nullopt;
        best->reserved = true; return best->id;
    }
};

// Алгоритъм 5: многокритериално ранкиране (min-max нормализация + тегла от потребителя)
struct Place { string name; double freeRatio, rating, distanceKm, price; double score = 0; };

void rankPlaces(vector<Place>& p, double wFree, double wRate, double wDist, double wPrice) {
    auto norm = [&](auto get, bool invert) {
        double lo = 1e9, hi = -1e9;
        for (auto& x : p) { lo = min(lo, get(x)); hi = max(hi, get(x)); }
        return [=](const Place& x) { double v = hi > lo ? (get(x) - lo) / (hi - lo) : 0.5; return invert ? 1 - v : v; };
    };
    auto nf = norm([](const Place& x) { return x.freeRatio; }, false);
    auto nr = norm([](const Place& x) { return x.rating; }, false);
    auto nd = norm([](const Place& x) { return x.distanceKm; }, true);
    auto np = norm([](const Place& x) { return x.price; }, true);
    for (auto& x : p) x.score = wFree * nf(x) + wRate * nr(x) + wDist * nd(x) + wPrice * np(x);
    sort(p.begin(), p.end(), [](auto& a, auto& b) { return a.score > b.score; });
}

int main() {
    Engine e;
    e.tables = {{1, 2, 2, 5, 4, 2}, {2, 12, 2, 5, 4, 4}, {3, 22, 2, 6, 4, 6}, {4, 2, 14, 5, 4, 2}, {5, 14, 14, 6, 4, 4}};
    mt19937 rng(7); normal_distribution<float> noise(0.f, 0.3f);
    Frame f;
    for (auto& r : f) for (auto& c : r) c = 22.f + noise(rng);
    for (int y = 3; y < 5; y++) for (int x = 13; x < 16; x++) f[y][x] += 9;   // гост на маса 2
    for (int y = 15; y < 17; y++) for (int x = 3; x < 5; x++) f[y][x] += 9;   // гост на маса 4
    for (int i = 0; i < 5; i++) e.update(f);

    cout << "Хора в кадъра: " << e.countPeople(f, 4.f) << "\n";
    for (auto& t : e.tables) cout << "Маса " << t.id << " (" << t.seats << " места): " << (t.occ ? "заета" : "свободна") << "\n";
    auto r = e.reserve(3);
    cout << "Резервация за 3 души: " << (r ? "маса " + to_string(*r) : "няма свободна") << "\n";

    vector<Place> ps = {{"Пълдин", 0.4, 4.7, 1.2, 3}, {"Хеброс", 0.7, 4.6, 0.8, 4}, {"Кафе Капана", 0.2, 4.4, 0.5, 2}};
    rankPlaces(ps, 0.4, 0.3, 0.2, 0.1);
    for (auto& p : ps) cout << p.name << " -> " << fixed << setprecision(2) << p.score << "\n";
    return 0;
}
